import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserHomeComponent } from './user-home/user-home.component';
import { VenderAuthGuard } from './vender-auth.guard';
import { VenderAuthComponent } from './vender-auth/vender-auth.component';
import { VenderDashboardComponent } from './vender-dashboard/vender-dashboard.component';

const routes: Routes = [
  {
    path: '',
    component:UserHomeComponent
  },
  {
    path: 'vender-auth',
    component: VenderAuthComponent
  },
  {
    path: 'vender-dashboard',
    component: VenderDashboardComponent,
    canActivate: [VenderAuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
