import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
@Component({
  selector: 'app-menu-header',
  templateUrl: './menu-header.component.html',
  styleUrls: ['./menu-header.component.css']
})
export class MenuHeaderComponent implements OnInit {
  menuTypes:String = "default";
  constructor(private route:Router) { }

  ngOnInit(): void {
    this.route.events.subscribe((val:any)=>{
      if(val.url){
        if(localStorage.getItem('vender') && val.url.includes('vender')){
          console.warn("seller area");
          this.menuTypes="vender"
        }else{
          console.warn("outside seller");
          this.menuTypes="default"
        }
      }
    })
  }

}
