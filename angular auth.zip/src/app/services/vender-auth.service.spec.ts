import { TestBed } from '@angular/core/testing';

import { VenderAuthService } from './vender-auth.service';

describe('VenderAuthService', () => {
  let service: VenderAuthService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(VenderAuthService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
