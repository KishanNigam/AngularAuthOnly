import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { venderSignIn, venderSignUp } from '../datatype';
import { BehaviorSubject, observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class VenderAuthService {
  isVenderLoggedIn = new BehaviorSubject<boolean>(false);
  isLogginErrorMSG = new EventEmitter<boolean>(false)


  constructor(private http: HttpClient, private route: Router) {}

  venderSignUp(data: venderSignUp) {
    this.http
      .post('http://localhost:3000/venderauth', data, { observe: 'response' })
      .subscribe((result) => {
        this.isVenderLoggedIn.next(true);
        localStorage.setItem('vender', JSON.stringify(result.body));
        this.route.navigate(['vender-dashboard']);
      });
  }
  reloadSeller() {
    if (localStorage.getItem('vender')) {
      this.isVenderLoggedIn.next(true);
      this.route.navigate(['vender-dashboard']);
    }
  }

  // Vender Sign in Function
  venderSignIn(data: venderSignIn) {
    this.http.get(`http://localhost:3000/venderauth?username=${data.username}&password=${data.password}`,
    {observe:'response'}).subscribe((result:any)=>{
     if(result && result.body && result.body.length){
       console.warn("User Logged in");
       localStorage.setItem('vender', JSON.stringify(result.body));
       this.route.navigate(['vender-dashboard']);
      }
      else{
        console.warn("no User Logged in");
        this.isLogginErrorMSG.emit(true)
      }
      
    })
  }


}
