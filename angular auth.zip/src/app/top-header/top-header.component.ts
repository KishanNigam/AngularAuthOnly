import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'

@Component({
  selector: 'app-top-header',
  templateUrl: './top-header.component.html',
  styleUrls: ['./top-header.component.css']
})
export class TopHeaderComponent implements OnInit {
  menuType:string = "default";
  constructor(private route: Router) { }

  ngOnInit(): void {
    this.route.events.subscribe((val:any)=>{
      if(val.url){
        if(localStorage.getItem('vender') && val.url.includes('vender')){
          console.warn("seller area");
          this.menuType="vender"
        }else{
          console.warn("outside seller");
          this.menuType="default"
        }
      }
    })
  }

  logOut(){
    localStorage.removeItem('vender');
    this.route.navigate(['/'])
  }

}
