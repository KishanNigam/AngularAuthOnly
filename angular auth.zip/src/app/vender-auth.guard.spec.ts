import { TestBed } from '@angular/core/testing';

import { VenderAuthGuard } from './vender-auth.guard';

describe('VenderAuthGuard', () => {
  let guard: VenderAuthGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(VenderAuthGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
