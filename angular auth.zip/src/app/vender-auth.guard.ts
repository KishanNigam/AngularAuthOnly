import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { VenderAuthService } from './services/vender-auth.service';

@Injectable({
  providedIn: 'root'
})
export class VenderAuthGuard implements CanActivate {
  constructor(private venderAuthService: VenderAuthService) {}
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if (localStorage.getItem('vender')) {
      return true 
      }
      return this.venderAuthService.isVenderLoggedIn;
  }
  
}
