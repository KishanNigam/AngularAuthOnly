import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VenderAuthComponent } from './vender-auth.component';

describe('VenderAuthComponent', () => {
  let component: VenderAuthComponent;
  let fixture: ComponentFixture<VenderAuthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VenderAuthComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VenderAuthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
