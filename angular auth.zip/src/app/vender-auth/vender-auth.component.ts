import { Component, OnInit } from '@angular/core';
import { VenderAuthService } from '../services/vender-auth.service';
import { Router } from '@angular/router';
import { venderSignUp } from '../datatype';

@Component({
  selector: 'app-vender-auth',
  templateUrl: './vender-auth.component.html',
  styleUrls: ['./vender-auth.component.css']
})
export class VenderAuthComponent implements OnInit {

  constructor(private venderAuth: VenderAuthService, private route:Router) { }

  showLogin=false
  vendarAuthError:string='';

  ngOnInit(): void {
    this.venderAuth.reloadSeller()
  }

  signUp(data: venderSignUp) : void {
    this.venderAuth.venderSignUp(data)
  }
  venderlogin(data: venderSignUp) : void {
    this.vendarAuthError=""
    this.venderAuth.venderSignIn(data);
    this.venderAuth.isLogginErrorMSG.subscribe((isError)=>{
      if(isError){
        this.vendarAuthError="UserName or Password is not Correct";
      }
    })
  }


  openLogin(){
    this.showLogin=true
  }
  openSignUp(){
    this.showLogin=false
  }
}


