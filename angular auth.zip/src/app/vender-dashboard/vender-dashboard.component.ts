import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vender-dashboard',
  templateUrl: './vender-dashboard.component.html',
  styleUrls: ['./vender-dashboard.component.css']
})
export class VenderDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
